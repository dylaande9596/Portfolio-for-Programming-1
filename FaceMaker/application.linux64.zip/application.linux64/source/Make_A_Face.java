import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Make_A_Face extends PApplet {

public void setup () {
  
  frameRate(1.5f);
  rectMode(CENTER);
}

public void draw () {
  background(255);
  strokeWeight(random(1, 5));
  makeHead();
  makeMouth();
  makeEyes();
}

public void makeHead() {
  // to do: draw and fill ellipse for cartoon head
  fill(255, random(200, 230), random(22, 200));
  ellipse(width/2, height/2, random(width*0.5f, width*0.9f), random(height*0.8f, height*0.89f));
}

public void makeMouth() {
  if (random(10)>3) {
    fill(205,60,30);
    ellipse(random(width*0.40f, width*0.55f), 
      random(height*0.7f, height*0.8f), 
      random(width*0.05f, width*0.25f), 
      random(height*0.05f, height*0.15f));
  } else if (random(10)>4) {
    fill(205,60,30);
    rect(random(width*0.4f, width*0.6f), 
      random(height*0.7f, height*0.8f), 
      random(width*0.1f, width*0.2f), 
      random(height*0.05f, height*0.1f));
  } else {
    line(width*0.4f, random(height*0.55f, height*0.65f), random(height*0.55f, height*0.65f), width*0.65f);
  }
}

public void mouseClicked() {
  saveFrame("line-######.png");
}

public void makeEyes() {
  fill(0);
  ellipse(random(width*0.3f, width*0.33f), 
    random(height*0.3f, height*0.35f), 
    random(width*0.05f, width*0.1f), 
    random(height*0.05f, height*0.15f));
  ellipse(random(width*0.6f, width*0.63f), 
    random(height*0.3f, height*0.35f), 
    random(width*0.05f, width*0.1f), 
    random(height*0.05f, height*0.15f));
}

public void makeNose() {
  fill(3);
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Make_A_Face" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
