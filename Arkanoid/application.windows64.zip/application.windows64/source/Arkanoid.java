import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Arkanoid extends PApplet {


Paddle [] paddles = new Paddle[1];
ArrayList<Ball> balls;
ArrayList<Stars> stars;
boolean play = false;
int xspeed, yspeed;
boolean started = false;
ArrayList<Brick> bricks = new ArrayList<Brick>();
BufferedReader reader;
int lives = 3;
int screenheight = 800;

public void setup() {
  
  paddles[0] = new Paddle();
  stars = new ArrayList<Stars>();
  balls = new ArrayList<Ball>();
  balls.add(new Ball(5000, 15/2, -7/2));
  loadLevel("one");
}
PImage photo;
PImage poto;
PImage oto;


public String readLine() {
  String line;
  try {
    line = reader.readLine();
  } 
  catch (IOException e) {
    e.printStackTrace();
    line = null;
  }
  return line;
}
// Display bricks
public void loadLevel(String levelName) {
  bricks.clear();
  reader = createReader("level"+levelName+".txt");
  int blockHeight = 50;
  int[] colors = {color(0xff94868F), color(0xffB5739D), color(0xffC3ABD0), color(0xff7EA6E0), color(0xffB9E0A5), color(0xffFFE599), color(0xffFFB570), color(0xffF19C99)};

  int rowCount = Integer.parseInt(readLine().trim());
  int columnCount = 0;
  for (int row = 0; row < rowCount; row++) {
    String line = readLine();
    String[] splitLine = line.split("");
    columnCount = splitLine.length;
    int blockWidth = width/columnCount;
    for (int column = 0; column < columnCount; column++) {
      String str = splitLine[column];
      if (!str.equals("0")) {
        bricks.add(new Brick(blockWidth*(column%columnCount), blockWidth+blockHeight*(row), colors[row%colors.length], blockHeight, blockWidth, Integer.parseInt(str)));
      }
    }
  }
}

public void draw() {
  textSize(20);
  background(2);
  if (!play) {
    startScreen();
    stars.add(new Stars(PApplet.parseInt(random(width)), 0));
    for (int i = stars.size()-1; i>=0; i--) {
      Stars star = (Stars) stars.get(i);
      star.move();
      star.display();      
      if (star.reachedBottom()) {
        stars.remove(star);
      }
    }
  } else {
    if (lives==0){
    lives +=3;
    play = false;
    }
    noCursor();
    text("Lives Left: "+ lives, width/10, height-100);
    stars.add(new Stars(PApplet.parseInt(random(width)), 0));
    for (int i = stars.size()-1; i>=0; i--) {
      Stars star = (Stars) stars.get(i);
      star.move();
      star.display();      
      if (star.reachedBottom()) {
        stars.remove(star);
      }
    }
    for (int x = 0; x < bricks.size(); x++) {
      if (bricks.get(x).hp > 0)
        bricks.get(x).display();
      else
        bricks.remove(x);
    }
    for (Ball ball : balls) {
      ball.display();
      if (!started) {
        ball.xpos = mouseX;
        ball.xspeed = 1;
        ball.yspeed = -7;
      } else {
        ball.move();
        for (Brick brick : bricks) {
          if (ball.ypos <= height&&ball.ypos>=height-30) {
            started = false;
            ball.ypos = PApplet.parseInt(height / 1.155f);
            //ball.ypos = int(height / 1.155);
            //ball.xspeed =0;
            //ball.yspeed = 0;
            lives -=1;
          }
          if (ball.xpos > brick.x  && ball.ypos > brick.y  && ball.xpos < (brick.x + brick.w-1)  && ball.ypos < (brick.y + brick.h-1)) {
            brick.hitByBall();
            ball.yspeed*=-1;
          }
        }
      }
    }
    paddles[0].display();
  }
}

public void startScreen() {

  background(0);
  textAlign(CENTER);
  photo = loadImage("darkandode.png");
  poto = loadImage("arkandode.png");
  oto = loadImage("dode.png");
  photo.resize(600, 150);
  poto.resize(600, 110);
  oto.resize(600, 100);
  image(photo, 100, 100);
  image(poto, 100, 210);
  image(oto, 100, 295);
  text("Player 1 press 'Enter'...", width/2, height/2+20);
}
public void keyPressed() {
  if (key == ENTER) {
    play = true;
  } else if (key == ' ') {
    started = true;
  }
}
class Ball {
  int xpos, ypos, xspeed, yspeed, c1, h, w;
  //  boolean isPU;
  Ball(int xpos, int xspeed, int yspeed) {
    this.xpos = xpos;
    ypos = PApplet.parseInt(height / 1.155f);
    h = w = 15;
    noStroke();
    c1 = color(130, 218, 212);
    this.xspeed = xspeed;
    this.yspeed = yspeed;
    //    this.isPU = isPU;
  }  
  public void display() {
    fill(c1);
    ellipse(xpos, ypos, h, w);
  }
  public void aim() {
    xpos = mouseX;
    xspeed = 1;
    yspeed = -7;
  }
  public void move() {

    xpos += xspeed;
    ypos += yspeed;
    if (xpos >= width-w || xpos <= w) {
      xspeed *= -1;
    }
    if (ypos >= height-h || ypos <= h) {
      yspeed *= -1;
    }
    //if (xpos >= mouseX-65 && xpos <= mouseX+60 && ypos >= (height/1.1555) && yspeed > 0){
    //  yspeed *= -1;
    //  //xspeed *= -1;
    //}

    if (xpos >= mouseX-65 && xpos <= mouseX && ypos >= (height/1.1555f) && yspeed > 0 && xspeed > 0) {
      if (xspeed==1) {
        xspeed += (-15/2);
      }
      yspeed *= -1;
      xspeed *= -1;
    }
    if (xpos >= mouseX-65 && xpos <= mouseX && ypos >= (height/1.1555f) && yspeed > 0 && xspeed < 0) {
      yspeed *= -1;
      if (xspeed==1) {
        xspeed += (15/2);
      }
    }
    if (xpos >= mouseX && xpos <= mouseX+60 && ypos >= (height/1.1555f) && yspeed > 0 && xspeed < 0) {
      yspeed *= -1;
      xspeed *= -1;
      if (xspeed==1) {
        xspeed += (-15/2);
      }
    }
    if (xpos >= mouseX && xpos <= mouseX+60 && ypos >= (height/1.1555f) && yspeed > 0 && xspeed > 0) {
      yspeed *= -1;
      if (xspeed==10) {
        xspeed += (15/2);
      }
    }
  }
}
// Alan Mo
// Created 3/5/19
class Brick {
  //member variables
  int x, y, w, h, hp;
  int c;

  // constructor
  Brick(int x, int y, int c, int h, int w, int hp) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.c = c;
    this.hp = hp;
  }

  //display method
  public void display() {
    strokeWeight(3);

    fill(c);
    rect(x, y, w-1, h-1);
  }

  public void hitByBall() {
    hp -= 1;
  }
}
//new Paddle(mouseX-62, height/1.15, 125, 15, 15, color(240, 144, 53)
// Alan Mo
// Created 3/5/19
class Paddle {
  //member variables
  float x, y, w, h;
  int c;

  // constructor
  Paddle() {
    y = height/1.15f;
    stroke(2);
    c = color(255,255,255);
    w = 125;
    h = 15;
  }

  //display method
  public void display() {
    fill(c);
    rect(mouseX-65, y, w, h);
  }
}
//new Paddle(mouseX-62, height/1.15, 125, 15, 15, color(240, 144, 53)
class Stars {
  int x, y, r; 
 float speed; 
  int h = PApplet.parseInt(random(40, 80));

  Stars(int x, int y) {
    this.x = x;
    this.y = y;
    r = PApplet.parseInt(random(2, 3));
    speed = random(3, 7);
  }

  public void display() {    
    noStroke();
    fill(48, 117, 200);
    ellipse(x, y, r+1, r+1);
    fill(205, 227, 238);
    ellipse(x-h, y, r+1, r+1); 
    ellipse(x, y+h, r+1, r+1);    
    ellipse(x+h, y, r+1, r+1);
  }

  public void move() {
    y += speed;
  }

  public boolean reachedBottom() {
    if (y > height + r*4) { 
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Arkanoid" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
