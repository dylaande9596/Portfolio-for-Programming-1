import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Calculator1 extends PApplet {

Button[] numBtns = new Button[10];
Button[] opBtns = new Button[12];
String displayVal, leftVal, rightVal;
char opVal;
float result;
boolean firstNum, dec;

int Red = color(150, 50, 80);


public void setup () {
  fill(40);
  rect(20, 15, 260, 425, 15);
  fill(255);
  ellipse(150, 415, 30, 30);
  ellipse(105, 45, 10, 10);
  ellipse(150, 45, 70, 10);
  stroke(255);
  line(20, 390, 280, 390);
  line(20, 65, 280, 65);
  line(20, 135, 280, 135);
  stroke(40);
  displayVal = "";
  leftVal = "";
  rightVal = "";
  opVal = ' ';
  result = 0.0f;
  firstNum = true;
  dec = false;
  
  numBtns[0] = new Button(100, 360, 140, 40, 0, Red);
  numBtns[1] = new Button(100, 310, 40, 40, 1, Red);
  numBtns[2] = new Button(150, 310, 40, 40, 2, Red);
  numBtns[3] = new Button(200, 310, 40, 40, 3, Red);
  numBtns[4] = new Button(100, 260, 40, 40, 4, Red);
  numBtns[5] = new Button(150, 260, 40, 40, 5, Red);
  numBtns[6] = new Button(200, 260, 40, 40, 6, Red);
  numBtns[7] = new Button(100, 210, 40, 40, 7, Red);
  numBtns[8] = new Button(150, 210, 40, 40, 8, Red);
  numBtns[9] = new Button(200, 210, 40, 40, 9, Red);

  opBtns[0] = new Button(200, 360, 40, 40, 0, Red).asOperator(".");
  opBtns[1] = new Button(250, 360, 40, 40, 0, Red).asOperator("=");
  opBtns[2] = new Button(250, 310, 40, 40, 0, Red).asOperator("+");
  opBtns[3] = new Button(250, 260, 40, 40, 0, Red).asOperator("-");
  opBtns[4] = new Button(250, 210, 40, 40, 0, Red).asOperator("*");
  opBtns[5] = new Button(250, 160, 40, 40, 0, Red).asOperator("÷");
  opBtns[6] = new Button(200, 160, 40, 40, 0, Red).asOperator("C");
  opBtns[7] = new Button(150, 160, 40, 40, 0, Red).asOperator("+/-");
  opBtns[8] = new Button(100, 160, 40, 40, 0, Red).asOperator("%");
  opBtns[9] = new Button(50, 160, 40, 40, 0, Red).asOperator("√");
  opBtns[10] = new Button(50, 210, 40, 40, 0, Red).asOperator("x²");
  opBtns[11] = new Button(50, 285, 40, 90, 0, Red).asOperator("^");
}

public void draw() {
  updateDisplay();
  for (int i=0; i<numBtns.length; i++)
  {
    numBtns[i].display();
    numBtns[i].hover();
  }
  for (int i=0; i<opBtns.length; i++)
  {
    opBtns[i].display();
    opBtns[i].hover();
  }
}

public void updateDisplay() {
  rectMode(CENTER);
  fill(40);
  rect(150, 100, 260, 68);
  fill(255);
  textSize(34);
  textAlign(RIGHT);
  text(displayVal, 260, 120);
}

public void mouseReleased() {
  for (int i=0; i<numBtns.length; i++) {
    if (numBtns[i].hov) {
      if (firstNum) {
        leftVal += str(numBtns[i].v);
        displayVal = leftVal;
      } else {
        rightVal += str(numBtns[i].v);
        displayVal = rightVal;
      }
    }
  }
  for (int i=0; i<opBtns.length; i++) {
    if (opBtns[i].hov) {
      if (opBtns[i].op == "+") {
        opVal = '+';
        displayVal = leftVal +"+";
        firstNum = false;
        dec = false;
      } else if (opBtns[i].op == "-") {
        opVal = '-';
        displayVal = leftVal +"-";
        firstNum = false;
        dec = false;
      } else if (opBtns[i].op == "*") {
        opVal = '*';
        displayVal = leftVal +"*";
        firstNum = false;
        dec = false;
      } else if (opBtns[i].op == "÷") {
        opVal = '÷';
        displayVal = leftVal +"÷";
        firstNum = false;
        dec = false;
      } else if (opBtns[i].op == "=") {
        performCalc();
        dec = false;
      } else if (opBtns[i].op == "C") {
        clearApp();
        dec = false;
      } else if (opBtns[i].op == ".") {
        if (!dec) {
          if (firstNum) {
            leftVal += opBtns[i].op;
            displayVal = leftVal;
            dec = true;
          } else {
            rightVal += opBtns[i].op;
            displayVal = rightVal;
            dec = true;
          }
        }
      } else if (opBtns[i].op == "+/-") {
        if (firstNum) {
          leftVal = displayVal = leftVal;
        } else {
          rightVal = displayVal = rightVal;
          dec = false;
        }
      } else if (opBtns[i].op == "√") {
        if (firstNum) 
          leftVal = str(sqrt(PApplet.parseFloat(leftVal)));
        displayVal = leftVal;
      } else  {
        rightVal = str(sqrt(PApplet.parseFloat(rightVal)));
        displayVal = rightVal;
        dec = false;
      }
    }
  }
}

public void performCalc() {
  if (opVal == '+') {
    result = PApplet.parseFloat(leftVal) + PApplet.parseFloat(rightVal);
    displayVal= str(result);
  } else if (opVal == '-') {
    result = PApplet.parseFloat(leftVal) - PApplet.parseFloat(rightVal);
    displayVal= str(result);
  } else if (opVal == '*') {
    result = PApplet.parseFloat(leftVal) * PApplet.parseFloat(rightVal);
    displayVal= str(result);
  } else if (opVal == '÷') {
    result = PApplet.parseFloat(leftVal) / PApplet.parseFloat(rightVal);
    displayVal= str(result);
  }
  leftVal = displayVal;
  firstNum = true;
  //dec = false;
}

public void clearApp() {
  displayVal = "";
  leftVal = "";
  rightVal = "";
  opVal = ' ';
  result = 0.0f;
  firstNum = true;
}

public void keyPressed () {
  if (key == '1') {
    handleKeyPress(true, "1");
  } else if (key == '2') {
    handleKeyPress(true, "2");
  } else if (key == '3') {
    handleKeyPress(true, "3");
  } else if (key == '4') {
    handleKeyPress(true, "4");
  } else if (key == '5') {
    handleKeyPress(true, "5");
  } else if (key == '6') {
    handleKeyPress(true, "6");
  } else if (key == '7') {
    handleKeyPress(true, "7");
  } else if (key == '8') {
    handleKeyPress(true, "8");
  } else if (key == '9') {
    handleKeyPress(true, "9");
  }
}

public void handleKeyPress(boolean num, String val) {
  if (num) {
    if (firstNum) {
      leftVal += val;
      displayVal = leftVal;
    } else {
      rightVal += val;
      displayVal = rightVal;
    }
  }
}
class Button {
  // Member Variables
  int x, y, w, h, v;
  int c;
  String op;
  boolean hov, asOperator;

  // Multiple Constructors for numbers and other buttons
  Button(int x, int y, int w, int h, int v, int c) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.v = v;
    this.c = c;
    hov = false;
  }

  public Button asOperator(String op) {
    this.op = op;
    asOperator = true;
    return this;
  }

  // Display Method
  public void display() {
    if (asOperator) {
      rectMode(CENTER);
      if (hov) {
        fill(0);
      } else {
        fill(255);
      }
      rect(x, y, w, h);
      textAlign(CENTER);
      fill(c);
      text(op, x, y+7);
    } else {
      rectMode(CENTER);
      if (hov) {
        fill(0);
      } else {
        fill(c);
      }
      rect(x, y, w, h);
      textAlign(CENTER, CENTER);
      textSize(20);
      fill(255);
      text(v, x, y);
    }
  }
  // Hover Method
  public void hover() {
    hov = mouseX > x-w/2 && mouseX < x+w/2 && mouseY > y-h/2 && mouseY < y+h/2;
  }
}
  public void settings() {  size(300, 450); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Calculator1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
