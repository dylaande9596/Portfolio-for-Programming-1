import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Etch_A_Sketch extends PApplet {

int x, y;

public void setup() {
  strokeWeight(3);
  
  frameRate(10);
  // Set start coords
  x = 0;
  y = 0;
}

public void draw() {
  fill(255);
  //keyPressed();
  drawName();
  noLoop();
}
public void mouseClicked() {
  saveFrame("line-######.png");
}

// Algorithm for your first name
public void drawName() {
  strokeWeight(1);
  moveRight(3);
  moveDown(24);
  strokeWeight(5);
  moveUp(10);
  moveRight(10);
  moveDown(1);
  moveRight(1);
  moveDown(18);
  moveLeft(1);
  moveDown(1);
  moveLeft(10);
  moveUp(10);
  moveDown(10);
  strokeWeight(1);
  moveDown(3);
  moveRight(19);
  moveUp(3);
  strokeWeight(7);
  moveLeft(5);
  moveUp(3);
  moveDown(3);
  moveRight(5);
  moveUp(12);
  moveLeft(5);
  moveRight(10);
  moveLeft(5);
  strokeWeight(1);
  moveDown(15);
  moveRight(8);
  moveUp(3);
  strokeWeight(10);
  moveUp(12);
  moveRight(7);
  moveDown(8);
  moveLeft(7);
  moveRight(7);
  moveDown(4);
  strokeWeight(1);
  moveDown(3);
  moveRight(5);
  moveLeft(15);
}

// Method to draw right line
public void moveRight(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x+i, y);
  }
  x=x+(10*rep);
}

public void moveLeft(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x-i, y);
  }
  x=x-(10*rep);
}

public void moveUp(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x, y-i);
  }
  y=y-(10*rep);
}

public void moveDown(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x, y+i);
  }
  y=y+(10*rep);
}

public void moveDownRight(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x-i, y-i);
  }
  y=y-(10*rep);
  x=x-(10*rep);
}



public void moveUpRight(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x+i, y+i);
  }
  x=x+(10*rep);
  y=y+(10*rep);
}

public void moveUpLeft(int rep) {
  for (int i=0; i<rep*10; i++) {
    point(x-i, y-i);
  }
  x=x+(10*rep);
  y=y+(10*rep);
}

public void keyPressed() {
  if (key == CODED) {
    if (keyCode == RIGHT) {
      moveRight(1);
    } else if (keyCode == DOWN) {
      moveDown(1);
    } else if (keyCode == LEFT) {
      moveLeft(1);
    } else if (keyCode == UP) {
      moveUp(1);
    }
  }
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Etch_A_Sketch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
