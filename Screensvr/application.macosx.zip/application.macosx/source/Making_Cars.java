import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Making_Cars extends PApplet {

Car[] myCars  =  new Car[500];

public void setup() {
  
  for (int i=0; i<myCars.length; i++) {
    myCars[i] = new Car(random(width), random(height), random(1, 20));
  }
}

public void draw() {
  background(100);
  for (int i=0; i<myCars.length; i++) {
    myCars[i].display();
    myCars[i].drive();
  }
}
class Car {
  //Member Variables
  int c;
  float x;
  float y;
  float s;
  boolean right;
  //Constructor
  Car(float x, float y, float s) {
    c = color(random(255), random(255), random(255));
    this.x = x;
    this.y = y;
    this.s = s;
    if (random(10)>5) {
      right = false;
    } else {
      right = true;
    }
  }
  //Display Method
  public void display() {
    rectMode(CENTER);
    fill(0);
    rect(x-8, y, 3, 14);
    rect(x+8, y, 3, 14);
    fill(c);
    rect(x, y, 20, 10);
  }
  //Drive Method
  public void drive() {
    if (right) {
      x+=s;
      if (x > width) {
        x = 0;
      }
      } else {
        x-=s; 
        if (x < 0) {
          x = width;
        }
      }
    }
  }
  public void settings() {  size(displayWidth, displayHeight); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Making_Cars" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
